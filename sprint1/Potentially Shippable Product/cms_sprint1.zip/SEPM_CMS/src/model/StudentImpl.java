package model;

/**
 * student class that contains student details for enrollment into courses in
 * course management system
 *
 */
public class StudentImpl extends AbstractStudent {

	public StudentImpl(String name, String address, int age) {
		super(name, address, age);
	}

}
