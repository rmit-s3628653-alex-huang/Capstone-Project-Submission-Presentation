package model;

import java.util.ArrayList;
import java.util.List;

import interfaces.Course;
import interfaces.Student;

public abstract class AbstractCourse implements Course {
	private String courseId, courseName, teacherName;
	private int studentEnrolled, maxStudent, charge, runCost;
	private int income, profit;
	private List<Student> studentList = new ArrayList<Student>();

	public AbstractCourse(String courseId, String courseName, String teacherName, int maxStudent, int charge,
			int runCost) {
		this.courseId = courseId;
		this.courseName = courseName;
		this.teacherName = teacherName;
		this.maxStudent = maxStudent;
		this.studentEnrolled = 0;
		this.charge = charge;
		this.runCost = runCost;
		this.profit = 0;
		this.income = 0;
		calculateRunCost();
	}

	public boolean enrol(StudentImpl student) {
		return false;
	}

	public boolean withdraw(String studentName) {
		return false;
	}

	public boolean checkEnrolledStatus(String studentName) {
		return false;
	}

	public boolean enrolValidator(String[] string) {
		return false;
	}

	public void displayFigures() {
		System.out.printf("%s: Students %d, Income %d, Cost %d, Profit %d\n", courseName, studentEnrolled, income, runCost,
				profit);
	}

	public void displayStudentList() {
		for (Student student : studentList) {
			System.out.println(student.getName() + ", " + student.getAddress() + ", " + student.getAge());
		}
	}

	public void figures() {
		// calculate run cost
		calculateRunCost();
		// calculate income
		income = 0;
		for (Student student : studentList) {
			// if student has past enrollment, apply discounted charge
			if (student.getPastEnrol()) {
				income += charge * DISCOUNT_PERCENT;
			}
			else {
				income += charge;
			}
		}
		// calculate profit
		profit = income - runCost;
	}

	public void calculateRunCost() {
		// calculate running cost for sewing course
		if (courseName == "Sewing") {
			runCost = 100 * studentEnrolled;
		}
	}

	public List<Student> getStudentList() {
		return studentList;
	}
	
	public void setStudentEnrolled(int studentEnrolled) {
		this.studentEnrolled = studentEnrolled;
	}
	
	@Override
	public String toString() {
		return "courseId='" + courseId + '\'' + ", courseName='" + courseName + '\'' + ", teacherName='" + teacherName
				+ '\'' + ", studentEnrolled=" + studentEnrolled + ", charge=" + charge + ", runCost=" + runCost;
	}
}
