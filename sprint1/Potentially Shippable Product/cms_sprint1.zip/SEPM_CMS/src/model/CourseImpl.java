package model;

/**
 * course class that contains course details for course management system
 *
 */
public class CourseImpl extends AbstractCourse {

	public CourseImpl(String courseId, String courseName, String teacherName, int maxStudent, int charge, int runCost) {
		super(courseId, courseName, teacherName, maxStudent, charge, runCost);
	}

}
