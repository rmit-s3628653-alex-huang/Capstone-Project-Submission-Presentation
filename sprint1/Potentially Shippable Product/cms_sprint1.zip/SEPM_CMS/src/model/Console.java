package model;

import java.util.List;
import java.util.Scanner;

import interfaces.Course;

/**
 * Utility class that implements helper methods
 *
 */
public class Console {

	/**
	 * print main menu to screen
	 */
	public void printMainMenu() {
		System.out.println("Course Management System");
		System.out.println("---------------------------");
		System.out.println("1. Add a student");
		System.out.println("2. Withdraw a student");
		System.out.println("3. Display a student list for a course");
		System.out.println("4. Display the course figures");
		System.out.println("5. Quit");
		System.out.println("Enter number option: ");
	}

	/**
	 * print enroll menu to screen
	 */
	public String[] printEnrolMenu(Scanner k1) {
		String[] s1 = new String[4];
		System.out.println("Enrol a student");
		System.out.println("---------------------------");
		System.out.println("Type in student name : ");
		s1[0] = k1.nextLine();
		System.out.println("Type in address : ");
		s1[1] = k1.nextLine();
		System.out.println("Type in age : ");
		s1[2] = k1.nextLine();
		System.out.println("Type in course : ");
		s1[3] = k1.nextLine();
		// string array of the student details
		return s1;
	}

	/**
	 * print withdraw menu to screen
	 */
	public String[] printWithdrawMenu(Scanner k1) {
		String[] s1 = new String[2];
		System.out.println("Withdraw a student");
		System.out.println("---------------------------");
		System.out.println("Enter in student name: ");
		s1[0] = k1.nextLine();
		System.out.println("Enter in course name: ");
		s1[1] = k1.nextLine();
		// string array of the student details
		return s1;

	}

	/**
	 * print course student list menu
	 */
	public String printCourseStudentMenu(Scanner k1) {
		String s1;
		System.out.println("Display student list");

		System.out.println("Enter course ID: ");
		s1 = k1.nextLine();

		return s1;
	}

	/**
	 * print course course figures
	 */
	public static void printCourseFigures(List<Course>courseList) {
		for (Course course : courseList) {
			course.displayFigures();
		}
	}

	/**
	 * method to save course data to file
	 */
	private void saveData() {

	}

	/**
	 * method to read course data from file
	 * 
	 * @return array of course if file is read successfully else return null
	 */
	private Course[] readData() {
		return null;
	}

	/**
	 * check for valid course Id from course list
	 * 
	 * @param courseList
	 *            list of existing courses
	 * @return true if valid course id is entered
	 */
	private boolean courseIdValidator(Course[] courseList) {
		return false;
	}

}
