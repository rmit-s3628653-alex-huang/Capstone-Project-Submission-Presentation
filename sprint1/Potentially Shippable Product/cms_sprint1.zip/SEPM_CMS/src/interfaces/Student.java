package interfaces;

/**
 * Student interface to implement method signature for students to enroll for
 * course management system
 */
public interface Student {

	public String getName();

	public String getAddress();

	public int getAge();
	
	public boolean getPastEnrol();
}
