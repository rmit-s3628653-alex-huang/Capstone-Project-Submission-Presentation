package driver;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import interfaces.Course;
import interfaces.Student;
import model.*;

public class CMS {

	private static List<Course> courseList = new ArrayList<Course>();

	public static void main(String[] args) {
		CourseImpl italianCooking = new CourseImpl("001", "Italian Cooking", "Adrian", 10, 500, 1000);
		CourseImpl seafoodCooking = new CourseImpl("002", "Seafood Cooking", "Adrian", 10, 700, 1000);
		CourseImpl sewing = new CourseImpl("003", "Sewing", "Adrian", 10, 300, 0);
		CourseImpl creativeWriting = new CourseImpl("004", "Creative Writing", "Adrian", 15, 200, 800);
		CourseImpl businessWriting = new CourseImpl("005", "Business Writing", "Adrian", 15, 200, 600);
		
		StudentImpl student1 = new StudentImpl("James Smith", "21 Baker Street", 35);
		StudentImpl student2 = new StudentImpl("Jane Jones", "", 24);
		StudentImpl student3 = new StudentImpl("Larry Berry", "1/9 Charles Court", 55);
		
		sewing.getStudentList().add(student1);
		sewing.getStudentList().add(student2);
		sewing.getStudentList().add(student3);
		sewing.setStudentEnrolled(3);
		italianCooking.getStudentList().add(student1);
		italianCooking.getStudentList().add(student2);
		italianCooking.getStudentList().add(student3);
		italianCooking.setStudentEnrolled(3);
		
		courseList.add(italianCooking);
		courseList.add(seafoodCooking);
		courseList.add(sewing);
		courseList.add(creativeWriting);
		courseList.add(businessWriting);
		
		// temporary fix for figures since enrollment for courses is not completed yet  
		for (Course course : courseList) {
			course.figures();
		}
		
		
		try (Scanner keyboard = new Scanner(System.in);) {
			Console console = new Console();
			boolean exit = false;
			String nav = "";
			while (exit == false) {
				if (mainProcess(console, keyboard, nav, exit)==true){
					exit = true;
				}
			}
		}
	}

	/**
	 * main process of CMS
	 * 
	 * @param console
	 *            console object to call console related functionalities
	 * 
	 * @param keyboard
	 *            scanner object to read input from the keyboard
	 * 
	 * @param nav
	 *            navigation option input read from user input
	 * 
	 * @param exit
	 *            boolean parameter to check for quit option
	 */
	private static boolean mainProcess(Console console, Scanner keyboard, String nav, Boolean exit) {
		console.printMainMenu();
		nav = keyboard.nextLine();
		switch (nav) {
		case "1":
			break;
		case "2":
			break;
		case "3":
			break;
		case "4":
			Console.printCourseFigures(courseList);
			break;
		case "5": 
			break;
		default:
			System.out.println("Incorrect nav number");
		}
		return exit;
	}

}
