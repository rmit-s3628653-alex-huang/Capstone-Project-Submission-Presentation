package model;

import java.io.Serializable;

/**
 * student class that contains student details for enrollment into courses in
 * course management system
 *
 */
public class StudentImpl extends AbstractStudent implements Serializable{

	private static final long serialVersionUID = 1L;

	public StudentImpl(String name, String address, int age) {
		super(name, address, age);
	}

}
