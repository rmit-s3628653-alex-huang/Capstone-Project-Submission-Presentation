package model;

import java.io.Serializable;

import interfaces.Student;

public abstract class AbstractStudent implements Student, Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private String address;
	private int age;
	private int courseFeeOwe;
	private boolean pastEnrol;

	public AbstractStudent(String name, String address, int age) {
		this.name = name;
		if (address.isEmpty()) {
			this.address = "Address Unknown";
		} else {
			this.address = address;
		}
		this.age = age;
		this.courseFeeOwe = 0;
		this.pastEnrol = false;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public int getAge() {
		return age;
	}

	public boolean getPastEnrol() {
		return pastEnrol;
	}

	public void setPastEnrol(boolean passEnrol) {
		this.pastEnrol = passEnrol;
	}
	
	public int getCourseFeeOwe() {
		return courseFeeOwe;
	}
	
	public void setCourseFeeOwe(int courseFeeOwe) {
		this.courseFeeOwe = courseFeeOwe;
	}

	@Override
	public String toString() {
		return "AbstractStudent{" + "name='" + name + '\'' + ", address='" + address + '\'' + ", age=" + age
				+ ", courseFeeOwe=" + courseFeeOwe + ", pastEnrol=" + pastEnrol + '}';
	}
}
