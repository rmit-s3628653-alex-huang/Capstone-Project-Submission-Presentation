package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import interfaces.Course;
import interfaces.Student;

public abstract class AbstractCourse implements Course, Serializable {

	private static final long serialVersionUID = 1L;
	private String courseId, courseName, teacherName;
	private int studentEnrolled, maxStudent, charge, runCost;
	private int income, profit;
	private List<Student> studentList = new ArrayList<Student>();

	public AbstractCourse(String courseId, String courseName, String teacherName, int maxStudent, int charge,
			int runCost) {
		this.courseId = courseId;
		this.courseName = courseName;
		this.teacherName = teacherName;
		this.maxStudent = maxStudent;
		this.studentEnrolled = 0;
		this.charge = charge;
		this.runCost = runCost;
		this.profit = 0;
		this.income = 0;
		calculateRunCost();
	}

	public boolean enrol(StudentImpl student, List<Student> studentList) {
		// do check here if student is currently enrolled before enrollment
		if (!checkEnrolledStatus(student.getName())) {
			// check if student has previous enrollment and apply discount
			for (Student tempStudent : studentList) {
				if (tempStudent.getName().equals(student.getName())) {
					student.setPastEnrol(true);
					break;
				}
			}
			// add course fee to student
			if (student.getPastEnrol()) {
				student.setCourseFeeOwe(student.getCourseFeeOwe() + (int) (charge * DISCOUNT_PERCENT));
			} else {
				student.setCourseFeeOwe(student.getCourseFeeOwe() + charge);
				studentList.add(student);
			}
		} else {
			System.out.println("Student is already enrolled");
			return false;
		}
		// add student to course and update course figures
		this.studentList.add(student);
		studentEnrolled++;
		figures();
		return true;
	}

	public boolean withdraw(String studentName) {
		return false;
	}

	public boolean checkEnrolledStatus(String studentName) {
		for (Student student : studentList) {
			if (student.getName().equals(studentName)) {
				return true;
			}
		}
		return false;
	}

	public boolean enrolValidator(String[] studentDetails) {
		// replaced space with + for temporary regex matching
		String tempMatcher = studentDetails[0].replaceAll("\\s", "+");
		// validate student name and age
		if (!tempMatcher.matches("[a-zA-Z+]*") || !studentDetails[2].matches("[0-9]*")) {
			return false;
		}
		// check that the course is not full
		if (studentEnrolled >= maxStudent) {
			return false;
		}
		return true;
	}

	public void displayFigures() {
		System.out.printf("%s: Students %d, Income %d, Cost %d, Profit %d\n", courseName, studentEnrolled, income,
				runCost, profit);
	}

	public void displayStudentList() {
		for (Student student : studentList) {
			System.out.printf("Student Name: %s, Address: %s, Age: %d\n", student.getName(), student.getAddress(),
					student.getAge());
		}
	}

	public void figures() {
		// calculate run cost
		calculateRunCost();
		// calculate income
		income = 0;
		for (Student student : studentList) {
			// if student has past enrollment, apply discounted charge
			if (student.getPastEnrol()) {
				income += charge * DISCOUNT_PERCENT;
			} else {
				income += charge;
			}
		}
		// calculate profit
		profit = income - runCost;
	}
	
	public void calculateRunCost() {
		// calculate running cost for sewing course
		if (courseName.equals("Sewing")) {
			runCost = 100 * studentEnrolled;
		}
	}

	public List<Student> getStudentList() {
		return studentList;
	}

	public void setStudentEnrolled(int studentEnrolled) {
		this.studentEnrolled = studentEnrolled;
	}

	public String getCourseId() {
		return courseId;
	}
	
	public String getCourseName() {
		return courseName;
	}
	
	@Override
	public String toString() {
		return "courseId='" + courseId + '\'' + ", courseName='" + courseName + '\'' + ", teacherName='" + teacherName
				+ '\'' + ", studentEnrolled=" + studentEnrolled + ", charge=" + charge + ", runCost=" + runCost;
	}
}
