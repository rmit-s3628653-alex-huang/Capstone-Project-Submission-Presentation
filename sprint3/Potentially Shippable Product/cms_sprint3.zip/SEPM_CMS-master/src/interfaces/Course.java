package interfaces;

import java.util.List;

import model.StudentImpl;

/**
 * Course Interface for implementing course method signature for course
 * management system
 */
public interface Course {

	double DISCOUNT_PERCENT = 0.8;

	/**
	 * enroll student into the course
	 * @param courseList 
	 * 
	 * @return true if student is successfully enrolled into the course
	 */
	public boolean enrol(StudentImpl student, List<Student> studentList, List<Course> courseList);

	/**
	 * withdraw student from the course
	 * 
	 * @param studentName
	 *            student name to be withdrawn from the course
	 * @param withdrawDetails 
	 * @param courseList 
	 * @return true if student is successfully withdrawn from the course
	 */
	public boolean withdraw(String studentName, List<Student> studentList, List<Course> courseList, String withdrawDetails);

	/**
	 * check if a particular student is enrolled in the course
	 * 
	 * @param studentName
	 *            the studentName to be checked
	 * @return true if the student is enrolled in the course
	 */
	public boolean checkEnrolledStatus(String studentName);

	/**
	 * check for valid enrollment details entered
	 * 
	 * @param studentDetails
	 *            list of entered student details
	 * 
	 * @return true if valid details are entered
	 */
	public boolean enrolValidator(String[] studentDetails);

	/**
	 * print income figures of course to screen
	 */
	public void displayFigures();

	/**
	 * print student list to the screen
	 */
	public void displayStudentList();

	/**
	 * Calculate figures for course income, cost and profit
	 */
	public void figures();

	/**
	 * Calculate run cost for sewing course
	 */
	public void calculateRunCost();

	public List<Student> getStudentList();

	public String getCourseId();

	public String getCourseName();

	public void setStudentEnrolled(int studentEnrolled);
	
	public void setCharge(int charge);

	public int getCharge();
}
