package model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import interfaces.Course;
import interfaces.Student;

import java.util.Random;
class ConsoleTest {

	@Test
	void testCheckEnrolment() {
		Console console = new Console();
		List<Course> courseList = new ArrayList<Course>();
		List<Student> studentList = new ArrayList<Student>();
		courseList = console.readCourseData();
		studentList = console.readStudentData();
		String[] enrol = new String[4];
		
		Random r = new Random();
		console.saveData(courseList, studentList);
		char c = (char)(r.nextInt(26) + 'a');
		char a = (char)(r.nextInt(26) + 'a');
		enrol[0] = "Fairy fire" ;
		enrol[1] = "Polaris Example Rd";
		enrol[2] = "23";
		enrol[3] = "002";
		
		console.checkEnrolment(enrol, courseList, studentList);
		console.saveData(courseList, studentList);
		
	}

}