package model;

import java.io.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import interfaces.Course;
import interfaces.Student;

/**
 * Utility class that implements helper methods
 *
 */
public class Console {

	/**
	 * print main menu to screen
	 */
	public void printMainMenu() {
		System.out.println("Course Management System");
		System.out.println("---------------------------");
		System.out.println("1. Add a student");
		System.out.println("2. Withdraw a student");
		System.out.println("3. Display a student list for a course");
		System.out.println("4. Display the course figures");
		System.out.println("5. Change Course fee");
		System.out.println("6. Quit");
		System.out.println("Enter number option: ");
	}

	/**
	 * print enroll menu to screen
	 */
	public String[] printEnrolMenu(Scanner k1) {
		String[] s1 = new String[4];
		System.out.println("Enrol a student");
		System.out.println("---------------------------");
		System.out.println("Type in student name : ");
		s1[0] = k1.nextLine();
		System.out.println("Type in address : ");
		s1[1] = k1.nextLine();
		System.out.println("Type in age : ");
		s1[2] = k1.nextLine();
		System.out.println("Type in course : ");
		s1[3] = k1.nextLine();
		// string array of the student details
		return s1;

	}

	public void checkEnrolment(String[] enrol, List<Course> courseList, List<Student> studentList) {
		boolean validCourse = courseIdValidator(courseList, enrol[3]);

		// check that course entered is a valid course
		if (validCourse) {
			for (Course course : courseList) {
				// check if student is already enrolled in the course
				if (course.getCourseId().equals(enrol[3])) {
					if (course.enrolValidator(enrol)) {
						StudentImpl newStudent = new StudentImpl(enrol[0], enrol[1], Integer.parseInt(enrol[2]), 0, false);
						boolean enrolStatus = course.enrol(newStudent, studentList, courseList);
						// if student is successfully enrolled into the course
						if (enrolStatus) {
							System.out.println(enrol[0] + " has been successfully enrolled into Course " + enrol[3]);
						} else {
							System.out.printf("%s is not enrolled into the course\n", enrol[0]);
						}
						break;
					} else {
						System.out.println(
								"Error: Student is not enrolled. Enter details is invalid or the course is already full.");
						break;
					}
				}
			}

		} else {
			System.out.println("The course id entered does not exist. Please try again\n");
			System.out.println();
		}

	}

	/**
	 * print withdraw menu to screen
	 */
	public String[] printWithdrawMenu(Scanner k1) {
		String[] s1 = new String[2];
		System.out.println("Withdraw a student");
		System.out.println("---------------------------");
		System.out.println("Enter a student name: ");
		s1[0] = k1.nextLine();
		System.out.println("Enter a course id: ");
		s1[1] = k1.nextLine();
		// string array of the student details
		return s1;
	}

	public void checkWithdraw(List<Course> courseList, List<Student> studentList, String[] withdrawDetails) {
		boolean withdrawStatus = false;
		for (Course course : courseList) {
			if (course.toString().matches("(.*)" + withdrawDetails[1] + "(.*)")) {
				if (course.checkEnrolledStatus(withdrawDetails[0])) {
					withdrawStatus = course.withdraw(withdrawDetails[0], studentList, courseList, withdrawDetails[1]);
					if (withdrawStatus) {
						System.out.printf("Student %s successfully withdrawn from course %s\n", withdrawDetails[0],
								withdrawDetails[1]);
					}
					break;
				} else {
					System.out.println("Student does not exist.");
					return;
				}
			}
		}
		if (!withdrawStatus) {
			System.out.println("Invalid course id input.");
		}
	}

	/**
	 * print course student list menu
	 */
	public void printCourseStudentMenu(Scanner k1, List<Course> courseList) {
		String selectedCourseId;
		System.out.println("Enter course ID: ");
		selectedCourseId = k1.nextLine();

		// go through all courses to find the specified course id
		boolean courseFound = false;
		for (Course course : courseList) {
			if (course.toString().matches("(.*)" + selectedCourseId + "(.*)")) {
				System.out.printf("== Students in %s ===\n", course.getCourseName());
				course.displayStudentList();
				courseFound = true;
				break;
			}
		}
		// if course is not found display error message
		if (!courseFound) {
			System.out.println("Invalid course Id entered. Please try again.");
		}
		System.out.println();
	}

	/**
	 * print course course figures
	 */
	public void printCourseFigures(List<Course> courseList) {
		for (Course course : courseList) {
			course.displayFigures();
			System.out.println(course.getStudentList());
		}
		System.out.println();
	}

	public void changeCourseFee(List<Course> courseList, Scanner k1) {
		System.out.println("Please enter course Id to change charge fees");
		String selectedCourseId = k1.nextLine();
		System.out.println("Please enter fee amount to update");
		int newFee = 0;
		try {
			newFee = k1.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("Invalid fee input! Fee input must be a number");
			return;
		}
		for (Course course : courseList) {
			// check if course id entered is valid
			if (course.getCourseId().equals(selectedCourseId)) {
				course.setCharge(newFee);
				course.figures();
				System.out.printf("Course %s's fee has been updated to %d\n", course.getCourseName(), newFee);
				return;
			}
		}
		System.out.println("Course id entered not valid. Please try again with a valid course id.");
	}

	/**
	 * method to save course and student data to file
	 */
	public void saveData(List<Course> courseList, List<Student> studentList) {
		// save course list as serializable object
		File courseDB = new File("CourseList.dat");
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(courseDB, false));) {
			out.writeObject(courseList);
		} catch (FileNotFoundException e) {
			System.out.println("Course File not found when saving data");
		} catch (IOException e) {
			System.out.println("IOException caught");
		}
		// save student list as serializable object
		File studentDB = new File("StudentList.dat");
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(studentDB, false));) {
			out.writeObject(studentList);
		} catch (FileNotFoundException e) {
			System.out.println("Student File not found when saving data");
		} catch (IOException e) {
			System.out.println("IOException caught");
		}

	}

	/**
	 * method to read course data from file
	 * 
	 * @return array of course if file is read successfully else return null
	 */
	public List<Course> readCourseData() {
		List<Course> courseList = new ArrayList<Course>();
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("CourseList.dat"));) {
			courseList = (List<Course>) in.readObject();
		} catch (EOFException e) {
			/* do nothing since we expect it */
		} catch (FileNotFoundException e) {
			System.out.println(" Course File not found when reading data");
		} catch (Exception e) {
			System.out.println("Unexpected error");
		}
		return courseList;
	}

	public List<Student> readStudentData() {
		List<Student> studentList = new ArrayList<Student>();
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("StudentList.dat"));) {
			studentList = (List<Student>) in.readObject();
		} catch (EOFException e) {
			/* do nothing since we expect it */
		} catch (FileNotFoundException e) {
			System.out.println("Student File not found when reading data");
		} catch (Exception e) {
			System.out.println("Unexpected error");
		}
		return studentList;
	}

	/**
	 * check for valid course Id from course list
	 * 
	 * @param courseList
	 *            list of existing courses
	 * @return true if valid course id is entered
	 */
	private boolean courseIdValidator(List<Course> courseList, String courseId) {
		for (Course course : courseList) {
			if (course.toString().matches("(.*)" + courseId + "(.*)")) {
				return true;
			}
		}
		return false;
	}

}
