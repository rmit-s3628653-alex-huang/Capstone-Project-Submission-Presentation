package model;

import java.io.Serializable;
import java.util.List;

import interfaces.Student;

/**
 * course class that contains course details for course management system
 *
 */
public class CourseImpl extends AbstractCourse implements Serializable {

	private static final long serialVersionUID = 1L;

	public CourseImpl(String courseId, String courseName, String teacherName, int maxStudent, int charge, int runCost, List<Student> studentList) {
		super(courseId, courseName, teacherName, maxStudent, charge, runCost, studentList);
	}

}
