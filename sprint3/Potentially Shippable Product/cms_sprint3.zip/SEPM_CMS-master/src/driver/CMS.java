package driver;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import interfaces.Course;
import interfaces.Student;

import model.Console;


public class CMS {

	private static Console console = new Console();
	private static List<Course> courseList = new ArrayList<Course>();
	private static List<Student> studentList = new ArrayList<Student>();

	public static void main(String[] args) {
		
		try (Scanner keyboard = new Scanner(System.in);) {
			// read in saved course and student data
			courseList = console.readCourseData();
			studentList = console.readStudentData();
			
			boolean exit = false;
			String nav = "";
			while (exit == false) {
				if (mainProcess(console, keyboard, nav, exit) == true) {
					exit = true;
				}
			}
		}
	}

	/**
	 * main process of CMS
	 * 
	 * @param console
	 *            console object to call console related functionalities
	 * 
	 * @param keyboard
	 *            scanner object to read input from the keyboard
	 * 
	 * @param nav
	 *            navigation option input read from user input
	 * 
	 * @param exit
	 *            boolean parameter to check for quit option
	 */
	private static boolean mainProcess(Console console, Scanner keyboard, String nav, Boolean exit) {
		console.printMainMenu();
		console.saveData(courseList, studentList);
		nav = keyboard.nextLine();
		switch (nav) {
		case "1":
			String[] enrol = console.printEnrolMenu(keyboard);
			console.checkEnrolment(enrol, courseList, studentList);
			break;
		case "2":
			String[] wd = console.printWithdrawMenu(keyboard);
			console.checkWithdraw(courseList, studentList, wd);
			break;
		case "3":
			console.printCourseStudentMenu(keyboard, courseList);
			break;
		case "4":
			console.printCourseFigures(courseList);
			break;
		case "5":
			console.changeCourseFee(courseList, keyboard);
			break;
		case "6":
			exit = true;
			System.out.println("Good bye");
			break;
		default:
			System.out.println("Incorrect nav number");
		}
		return exit;
	}

}
